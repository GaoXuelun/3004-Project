Team 44:
Zhen Feng, 101172075
Yuhan Wang, 101165518
Yibo Sun, 101082357

files:
OASIS.pro
OASIS.pro.user
battery.cpp
battery.h
connection.cpp
connection.h
dbmanager.cpp
dbmanager.h
main.cpp
mainwindow.cpp
mainwindow.h
mainwindow.ui
therapy.cpp
therapy.h

Use Case.pdf
Sequence Diagram.pdf
UML.pdf
Requirement Traceability Matrix.pdf

Zhen Feng: data base, some of program logic, some of Requirement Traceability Matrix, some of UI
Yibo Sun: most of program logic, most of UI
Yuhan Wang: Use case, Sequence diagram, UML, most of Requirement Traceability Matrix